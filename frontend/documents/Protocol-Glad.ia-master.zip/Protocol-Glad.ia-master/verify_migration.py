
import sys
import os
from unittest.mock import MagicMock, patch

# Add project root to sys.path
sys.path.append(os.getcwd())

# Mock settings
import app.core.config
app.core.config.settings.GOOGLE_API_KEY = "fake_key"

# Mock specific imports to avoid triggering actual LLM calls
# Mock storage and model to avoid import errors if paths are different
with patch('app.core.agno_agent.SqliteDb') as mock_storage, \
     patch('app.core.agno_agent.Gemini') as mock_gemini:
     
    # Import modules to test their structure and instantiation
    from app.core.tools import get_session_state, criar_ferramenta_gerar_protocolo
    from app.core.agno_agent import get_team
    from app.core.crew import ProtocoloCriacao

    def test_migration_structure():
        print("--- Testing Migration Structure ---")
        
        # 1. Test Tools & Session State
        print("1. Testing Tools & Session State...")
        session_id = "test_migration"
        state = get_session_state(session_id)
        assert state["status"] == "EM_CONSTRUCAO"
        print("   -> Session state initialized correctly.")
        
        # 2. Test Agno Team Creation
        print("2. Testing Agno Team Creation...")
        try:
            team = get_team(session_id)
            print(f"   -> Team '{team.name}' created successfully.")
            # Check members
            member_names = [m.name for m in team.members]
            print(f"   -> Members: {member_names}")
            assert "Glad.IA - Consultora de Luxo" in member_names
            assert "Designer Visual de Luxo" in member_names
        except Exception as e:
            print(f"   -> ERROR creating team: {e}")
            return

        # 3. Test CrewAI Class Loading
        print("3. Testing CrewAI Class Loading...")
        try:
            # We need to mock os.environ for the LLM init in crew.py
            os.environ["GOOGLE_API_KEY"] = "fake_key"
            crew_instance = ProtocoloCriacao()
            print("   -> ProtocoloCriacao instance created.")
            print(f"   -> Agents config loaded: {list(crew_instance.agents_config.keys())}")
            print(f"   -> Tasks config loaded: {list(crew_instance.tasks_config.keys())}")
        except Exception as e:
             print(f"   -> ERROR loading CrewAI: {e}")
             # This might fail if the yaml files aren't found, which is a good test
             return

        print("\nSUCCESS: All structural migration tests passed.")

if __name__ == "__main__":
    test_migration_structure()
