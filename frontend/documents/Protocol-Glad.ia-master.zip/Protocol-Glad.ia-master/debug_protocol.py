import sys
import os
import uuid

# Adiciona o diretório atual ao path para importar os módulos do app
sys.path.append(os.getcwd())

from app.core.tools import (
    get_session_state, 
    criar_ferramenta_preencher_teste, 
    criar_ferramenta_gerar_protocolo
)

def test_protocol_generation():
    session_id = f"test-{uuid.uuid4().hex[:8]}"
    print(f"--- Iniciando Teste de Protocolo (Sessão: {session_id}) ---")
    
    # 1. Preencher dados de teste
    preencher_tool = criar_ferramenta_preencher_teste(session_id)
    result_preencher = preencher_tool()
    print(f"\n[PASSAR 1] Preenchimento: {result_preencher}")
    
    state = get_session_state(session_id)
    if state["nome_medico"] == "Cristiano Ronaldo":
        print("✅ Dados de teste preenchidos com sucesso.")
    else:
        print("❌ Falha ao preencher dados de teste.")
        return

    # 2. Gerar protocolo
    gerar_tool = criar_ferramenta_gerar_protocolo(session_id)
    print("\n[PASSAR 2] Disparando geração de protocolo (CrewAI)...")
    try:
        result_gerar = gerar_tool()
        print(f"\nResultado da Ferramenta:\n{result_gerar}")
        
        # 3. Verificar se arquivos foram criados
        if "[[DOWNLOAD:" in result_gerar:
            print("\n✅ Tag de download encontrada.")
            # Extrair os arquivos da tag
            import re
            links = re.findall(r'/documents/(protocolo_[a-f0-9]+\.(?:md|docx|pdf))', result_gerar)
            
            for link in links:
                file_path = os.path.join("frontend", "documents", link)
                if os.path.exists(file_path):
                    print(f"✅ Arquivo verificado: {file_path}")
                else:
                    print(f"❌ Arquivo NÃO encontrado: {file_path}")
        else:
            print("\n❌ Tag de download NÃO encontrada no resultado.")
            
    except Exception as e:
        print(f"\n❌ Erro crítico durante o teste: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_protocol_generation()
