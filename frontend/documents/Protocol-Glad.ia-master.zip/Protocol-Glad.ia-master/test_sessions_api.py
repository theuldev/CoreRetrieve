
import requests
import uuid
import sys

API_URL = "http://localhost:8000/api/v1"

def test_sessions():
    print("--- Testing Session Limits ---")
    
    # 1. Clear all sessions first to start clean
    print("\n1. Clearing all sessions...")
    try:
        requests.delete(f"{API_URL}/sessions/")
    except Exception as e:
        print(f"Error clearing sessions: {e}. Is server running?")
        return

    # 2. Create 5 sessions
    print("\n2. Creating 5 sessions...")
    session_ids = []
    for i in range(5):
        sid = str(uuid.uuid4())
        session_ids.append(sid)
        resp = requests.post(f"{API_URL}/chat/", json={
            "message": f"Hello session {i}",
            "session_id": sid,
            "stream": False
        })
        if resp.status_code == 200:
            print(f"  Session {i+1} created: {sid}")
        else:
            print(f"  Failed to create session {i+1}: {resp.status_code} - {resp.text}")

    # 3. Try to create 6th session (Should Fail)
    print("\n3. Attempting to create 6th session (Expect 403)...")
    sid_fail = str(uuid.uuid4())
    resp = requests.post(f"{API_URL}/chat/", json={
        "message": "This should fail",
        "session_id": sid_fail,
        "stream": False
    })
    
    if resp.status_code == 403:
        print("  SUCCESS: Request was forbidden as expected.")
    else:
        print(f"  FAILURE: Request returned {resp.status_code}. Expected 403.")

    # 4. Delete one session
    print("\n4. Deleting one session...")
    to_delete = session_ids[0]
    resp = requests.delete(f"{API_URL}/sessions/{to_delete}")
    if resp.status_code == 200:
        print(f"  Deleted session {to_delete}")
    else:
        print(f"  Failed delete: {resp.status_code}")

    # 5. Try creating again (Should Succeed)
    print("\n5. Attempting to create session after deletion (Expect 200)...")
    sid_new = str(uuid.uuid4())
    resp = requests.post(f"{API_URL}/chat/", json={
        "message": "This should work now",
        "session_id": sid_new,
        "stream": False
    })
    
    if resp.status_code == 200:
        print("  SUCCESS: Request succeeded.")
    else:
        print(f"  FAILURE: Request returned {resp.status_code}. Expected 200.")
        
    # 6. List sessions
    print("\n6. Listing sessions...")
    resp = requests.get(f"{API_URL}/sessions/")
    sessions = resp.json()
    print(f"  Active sessions: {len(sessions)}")
    for s in sessions:
        print(f"  - {s['title']} ({s['session_id']})")

if __name__ == "__main__":
    test_sessions()
