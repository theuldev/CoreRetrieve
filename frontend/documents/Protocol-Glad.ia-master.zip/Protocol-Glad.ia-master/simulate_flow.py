
import sys
import os
from unittest.mock import MagicMock, patch

# Add project root to sys.path
sys.path.append(os.getcwd())

# Mock settings
import app.core.config
app.core.config.settings.GOOGLE_API_KEY = "fake_key"

def simulate_full_flow():
    print("\n--- SIMULATION: AGNO -> CREWAI INTEGRATION ---")
    
    # 1. Mocking External Services to avoid real API calls and focus on logic flow
    with patch('app.core.agno_agent.SqliteDb') as mock_db, \
         patch('app.core.agno_agent.Gemini') as mock_gemini, \
         patch('app.core.crew.LLM') as mock_llm_crew:
         
        print("[1] Services Mocked (DB, Gemini, CrewLLM)")
        
        # Import tools after mocking to ensure they use mocks if needed
        from app.core.tools import get_session_state, criar_ferramenta_gerar_protocolo
        
        # 2. Simulate Agno interacting and filling session state
        session_id = "simulation_user_123"
        print(f"[2] Simulating User Session: {session_id}")
        
        state = get_session_state(session_id)
        state["nome_medico"] = "Dr. Silva"
        state["especialidade"] = "Dermatologista"
        state["missao_autoridade"] = "Realçar a beleza natural"
        state["tempo_experiencia"] = "15 anos"
        state["dor_paciente"] = "Medo de envelhecer mal"
        state["prognostico_nao_tratamento"] = "Perda de autoestima irrevelsível"
        state["fases"] = {
            "fase_1": "Limpeza Profunda", 
            "fase_2": "Estimulação de Colágeno", 
            "fase_3": "Manutenção Mensal"
        }
        state["valor_protocolo"] = "R$ 5.000,00"
        state["valor_avulso"] = "R$ 7.000,00"
        state["bonus_inclusos"] = ["Kit Home Care"]
        state["briefing_visual"] = {"estilo": "Minimalista", "cores": "Gold", "formato": "PDF"}
        
        print("   -> Session State Populated:")
        print(f"      Medico: {state['nome_medico']}")
        print(f"      Financeiro: {state['valor_protocolo']}")
        
        # 3. Trigger Tool: criar_ferramenta_gerar_protocolo
        print("[3] Triggering 'gerar_protocolo' tool...")
        trigger_func = criar_ferramenta_gerar_protocolo(session_id)
        
        # We need to mock the actual Crew execution inside crew_swarm to avoid needing a real LLM response,
        # but we want to verify that inputs are passed correctly.
        with patch('app.core.crew_swarm.ProtocoloCriacao') as MockProtocoloCriacao:
            # Mock the crew().kickoff() return value
            mock_instance = MockProtocoloCriacao.return_value
            mock_crew = MagicMock()
            mock_output = MagicMock()
            mock_output.raw = "# Protocolo Gerado\n\nTexto simulado do protocolo..."
            
            mock_crew.kickoff.return_value = mock_output
            mock_instance.crew.return_value = mock_crew
            
            # Execute tool
            response = trigger_func()
            
            print("[4] Tool Execution Completed")
            print("   -> Checking Inputs passed to Crew...")
            
            # Verify kickoff was called with correct inputs
            args, kwargs = mock_crew.kickoff.call_args
            inputs_passed = kwargs.get('inputs', {})
            
            print(f"      Inputs: {inputs_passed}")
            assert inputs_passed['perfil_medico'] == "Dr. Silva (Dermatologista) - Realçar a beleza natural - Exp: 15 anos"
            assert "Medo de envelhecer mal" in inputs_passed['dores_paciente']
            
            print("   -> Checking Output Response...")
            print(f"      Response Preview: {response[:100]}...")
            
            # Verify Download Link
            if "[[DOWNLOAD: /documents/" in response:
                print("   -> SUCCESS: Download link found!")
                import re
                match = re.search(r'\[\[DOWNLOAD: (.*?)\]\]', response)
                if match:
                    print(f"      Link: {match.group(1)}")
            else:
                print("   -> FAILURE: Download link NOT found.")
                raise Exception("Download link missing in response")
                
            print("\n--- SIMULATION SUCCESSFUL ---")

if __name__ == "__main__":
    simulate_full_flow()
