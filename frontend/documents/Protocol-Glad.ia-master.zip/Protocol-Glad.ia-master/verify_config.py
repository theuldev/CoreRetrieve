
import sys
import os
from unittest.mock import MagicMock, patch

# Add project root
sys.path.append(os.getcwd())

# Mock Settings
from app.core.config import settings

def verify_config():
    print("--- VERIFYING CONFIGURATION ---")
    
    # 1. Check Settings
    print(f"Settings Model: {settings.AI_MODEL_NAME}")
    
    # 2. Check CrewAI Model Logic
    # We patch CrewBase and LLM to avoid real instantiation issues
    with patch('app.core.crew.CrewBase') as MockCrewBase, \
         patch('app.core.crew.LLM') as MockLLM:
         
        # Make CrewBase decorator just return the class
        MockCrewBase.side_effect = lambda cls: cls
        
        from app.core.crew import ProtocoloCriacao
        
        crew_instance = ProtocoloCriacao()
        
        # Verify LLM call args
        args, kwargs = MockLLM.call_args
        model_passed = kwargs.get('model')
        
        print(f"CrewAI Model passed to LLM: {model_passed}")
        
        expected = f"gemini/{settings.AI_MODEL_NAME}"
        
        if model_passed == expected:
             print("SUCCESS: CrewAI model matches settings.")
        else:
             print(f"FAILURE: CrewAI model mismatch. Got '{model_passed}', expected '{expected}'")

if __name__ == "__main__":
    verify_config()
