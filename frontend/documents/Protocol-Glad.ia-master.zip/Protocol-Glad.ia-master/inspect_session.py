
import asyncio
import os
import sys
from pprint import pprint

# Add project root to sys.path
sys.path.append(os.getcwd())

from app.core.agno_agent import get_agno_agent, db
from agno.db.base import SessionType

def inspect_agent_memory():
    # Fetch a session ID to test
    sessions = db.get_sessions(session_type=SessionType.TEAM)
    if not sessions:
        print("No sessions found.")
        return

    session_id = sessions[-1].session_id
    print(f"Testing Session ID: {session_id}")

    agent = get_agno_agent(session_id)
    
    # Check if we can get messages
    # Try different potential attributes
    if hasattr(agent, "memory"):
        print(f"Agent has 'memory' attribute: {type(agent.memory)}")
        # Check if memory has messages
        if hasattr(agent.memory, "messages"):
            print(f"Memory messages count: {len(agent.memory.messages)}")
        elif hasattr(agent.memory, "get_messages"):
            msgs = agent.memory.get_messages()
            print(f"Memory get_messages() count: {len(msgs) if msgs else 0}")
    
    if hasattr(agent, "memory_manager"):
        print(f"Agent has 'memory_manager': {type(agent.memory_manager)}")
        # Try getting messages from manager
        # Usually memory_manager.get_messages(session_id)
    
    # Check if we can read directly from DB using session_id
    # db.get_session(session_id) -> Session object
    # Does Session object field 'memory' contain messages?
    session_data = db.get_session(session_id, SessionType.TEAM)
    if hasattr(session_data, "memory"):
        print("Session data has 'memory' field.")
        if isinstance(session_data.memory, dict) and "messages" in session_data.memory:
             print(f"Messages in session.memory['messages']: {len(session_data.memory['messages'])}")
        else:
             print(f"Session memory type: {type(session_data.memory)}")
             pprint(session_data.memory)

if __name__ == "__main__":
    inspect_agent_memory()
