
const API_BASE = 'http://localhost:8000/api/v1';

const chatForm = document.getElementById('chat-form');
const userInput = document.getElementById('user-input');
const chatContainer = document.getElementById('chat-container').querySelector('.max-w-3xl');
const sendBtn = document.getElementById('send-btn');
const historyList = document.getElementById('history-list');
const newChatBtn = document.getElementById('new-chat-btn');
const clearMemoryBtn = document.getElementById('clear-memory-btn');

// Sidebar Elements
const sidebar = document.getElementById('sidebar');
const openSidebarBtn = document.getElementById('open-sidebar-btn');
const closeSidebarBtn = document.getElementById('close-sidebar-btn');
const sidebarOverlay = document.getElementById('sidebar-overlay');

// Modal & Toast Elements
const confirmModal = document.getElementById('confirm-modal');
const confirmOverlay = document.getElementById('confirm-overlay');
const confirmCard = document.getElementById('confirm-card');
const confirmTitle = document.getElementById('confirm-title');
const confirmMessage = document.getElementById('confirm-message');
const confirmCancelBtn = document.getElementById('confirm-cancel-btn');
const confirmOkBtn = document.getElementById('confirm-ok-btn');
const toastContainer = document.getElementById('toast-container');

// Settings Elements
const settingsModal = document.getElementById('settings-modal');
const settingsOverlay = document.getElementById('settings-overlay');
const settingsCard = document.getElementById('settings-card');
const openSettingsBtn = document.getElementById('open-settings-btn');
const closeSettingsBtn = document.getElementById('close-settings-btn');
const themeSelect = document.getElementById('theme-select');
const aiModelName = document.getElementById('ai-model-name');

let sessionId = null;
let statusInterval = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    init();
    setupSidebar();
});

async function init() {
    await loadSessions();
    setupSettings();
    loadTheme();
}

function setupSidebar() {
    function toggleSidebar() {
        const isClosed = sidebar.classList.contains('-translate-x-full');
        if (isClosed) {
            sidebar.classList.remove('-translate-x-full');
            sidebarOverlay.classList.remove('hidden', 'opacity-0');
        } else {
            sidebar.classList.add('-translate-x-full');
            sidebarOverlay.classList.add('hidden', 'opacity-0');
        }
    }

    openSidebarBtn.addEventListener('click', toggleSidebar);
    closeSidebarBtn.addEventListener('click', toggleSidebar);
    sidebarOverlay.addEventListener('click', toggleSidebar);

    newChatBtn.addEventListener('click', createNewChat);
    clearMemoryBtn.addEventListener('click', clearAllMemory);
}

// --- Session Management ---

async function loadSessions() {
    try {
        const response = await fetch(`${API_BASE}/sessions/`);
        if (!response.ok) throw new Error('Failed to load sessions');
        const sessions = await response.json();

        renderSessionList(sessions);

        // If no session selected yet, select the most recent one if available
        if (!sessionId && sessions.length > 0) {
            loadChat(sessions[0].session_id);
        } else if (!sessionId && sessions.length === 0) {
            startNewSessionUI();
        }
    } catch (error) {
        console.error('Error loading sessions:', error);
        historyList.innerHTML = '<div class="text-center text-red-400 text-xs p-4">Erro ao carregar histórico</div>';
    }
}

function renderSessionList(sessions) {
    historyList.innerHTML = '';

    if (sessions.length === 0) {
        historyList.innerHTML = '<div class="text-center text-gray-600 text-sm py-4 italic">Nenhuma conversa anterior</div>';
        return;
    }

    sessions.forEach(session => {
        const div = document.createElement('div');
        div.className = `p-3 rounded-lg cursor-pointer hover:bg-luxury-gold/5 transition-colors group relative flex justify-between items-center ${session.session_id === sessionId ? 'bg-luxury-gold/10 border border-luxury-gold/20' : ''}`;

        const dateStr = new Date(session.created_at * 1000).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

        div.innerHTML = `
            <div class="flex-1 min-w-0" onclick="loadChat('${session.session_id}')">
                <h3 class="text-sm font-medium text-gray-200 truncate pr-2">${session.title || 'Nova Conversa'}</h3>
                <p class="text-[10px] text-gray-500">${dateStr}</p>
            </div>
            <button onclick="deleteSession('${session.session_id}', event)" class="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-400 transition-opacity p-1">
                <i data-lucide="trash" class="w-3 h-3"></i>
            </button>
        `;
        historyList.appendChild(div);
    });
    lucide.createIcons();
}

async function createNewChat() {
    // Check limit on frontend (optional, backend enforces it)
    const currentSessions = document.querySelectorAll('#history-list > div').length;
    if (currentSessions >= 5) {
        showToast('Limite de 5 conversas atingido. Apague uma conversa antiga para iniciar uma nova.', 'warning');
        return;
    }

    startNewSessionUI();
}

function startNewSessionUI() {
    sessionId = crypto.randomUUID();
    clearChatUI();
    // Deselect active in list
    document.querySelectorAll('#history-list > div').forEach(el => {
        el.classList.remove('bg-luxury-gold/10', 'border', 'border-luxury-gold/20');
    });

    // Add welcome message back
    addWelcomeMessage();
}

async function loadChat(id) {
    if (sessionId === id) return; // Already loaded
    sessionId = id;

    // Update UI highlights
    loadSessions(); // Re-render to highlight active one

    clearChatUI();
    showTypingIndicator(); // Show loading state

    try {
        const response = await fetch(`${API_BASE}/sessions/${id}/history`);
        if (!response.ok) throw new Error('Failed to load history');
        const messages = await response.json();

        removeTypingIndicator();
        removeGeneratingIndicator();

        if (messages.length === 0) {
            addWelcomeMessage();
        } else {
            // Render messages
            messages.forEach(msg => {
                addMessage(msg.content, msg.role === 'user' ? 'user' : 'ai');
            });
        }
    } catch (error) {
        console.error('Error loading chat:', error);
        removeTypingIndicator();
        removeGeneratingIndicator();
        addMessage('Erro ao carregar histórico da conversa.', 'ai', true);
    }
}

async function deleteSession(id, event) {
    if (event) event.stopPropagation();

    const confirmed = await showConfirmModal(
        'Apagar Conversa',
        'Tem certeza que deseja apagar esta conversa? Esta ação não pode ser desfeita.'
    );
    if (!confirmed) return;

    try {
        await fetch(`${API_BASE}/sessions/${id}`, { method: 'DELETE' });

        if (sessionId === id) {
            startNewSessionUI();
        }
        showToast('Conversa apagada com sucesso.', 'success');
        loadSessions(); // Refresh list
    } catch (error) {
        console.error('Error deleting session:', error);
        showToast('Erro ao apagar conversa. Tente novamente.', 'error');
    }
}

async function clearAllMemory() {
    const confirmed = await showConfirmModal(
        'Apagar Toda Memória',
        'ATENÇÃO: Isso apagará TODAS as conversas e a memória completa da IA. Esta ação é irreversível.'
    );
    if (!confirmed) return;

    try {
        await fetch(`${API_BASE}/sessions/`, { method: 'DELETE' });
        startNewSessionUI();
        loadSessions();
        showToast('Toda a memória foi apagada.', 'success');
    } catch (error) {
        console.error('Error clearing memory:', error);
        showToast('Erro ao limpar memória. Tente novamente.', 'error');
    }
}

// --- Chat Logic ---

userInput.addEventListener('input', function () {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
    sendBtn.disabled = this.value.trim() === '';
});

userInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!sendBtn.disabled) {
            sendBtn.click();
        }
    }
});

chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = userInput.value.trim();
    if (!message) return;

    if (!sessionId) {
        sessionId = crypto.randomUUID();
    }

    // Add User Message
    addMessage(message, 'user');
    userInput.value = '';
    userInput.style.height = 'auto';
    sendBtn.disabled = true;

    // Show Typing Indicator
    showTypingIndicator();
    startStatusPolling();

    try {
        const response = await fetch(`${API_BASE}/chat/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                session_id: sessionId,
                stream: false
            })
        });

        if (response.status === 403) {
            const data = await response.json();
            stopStatusPolling();
            removeTypingIndicator();
            removeGeneratingIndicator();
            showToast(data.detail, 'warning');
            // Verify if we should refresh list
            loadSessions();
            return;
        }

        if (!response.ok) throw new Error('Network response was not ok');

        const data = await response.json();

        // Remove Typing Indicator
        stopStatusPolling();
        removeTypingIndicator();
        removeGeneratingIndicator();

        // Add AI Message
        addMessage(data.response, 'ai');

        if (data.session_id) {
            sessionId = data.session_id;
        }

        // Refresh session list (to update title/order)
        loadSessions();

    } catch (error) {
        console.error('Error:', error);
        stopStatusPolling();
        removeTypingIndicator();
        removeGeneratingIndicator();
        addMessage('Desculpe, ocorreu um erro ao processar sua solicitação. Tente novamente.', 'ai', true);
    }
});

// --- Polling & UI Generation Logic ---

let isGenerating = false;

function startStatusPolling() {
    isGenerating = false;
    if (statusInterval) clearInterval(statusInterval);
    statusInterval = setInterval(checkStatus, 500); // 500ms para capturar mais rápido a transição
}

function stopStatusPolling() {
    if (statusInterval) {
        clearInterval(statusInterval);
        statusInterval = null;
    }
}

async function checkStatus() {
    if (!sessionId) return;
    try {
        const res = await fetch(`${API_BASE}/sessions/${sessionId}/status`);
        if (res.ok) {
            const data = await res.json();
            if (data.status === 'GERANDO_PROTOCOLO' && !isGenerating) {
                isGenerating = true;
                removeTypingIndicator();
                showGeneratingIndicator();
            }
        }
    } catch (e) {
        console.error("Error polling status:", e);
    }
}

function showGeneratingIndicator() {
    if (document.getElementById('generating-indicator-bubble')) return;

    const div = document.createElement('div');
    div.id = 'generating-indicator-bubble';
    div.className = 'flex gap-4 animate-fade-in group';

    div.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-luxury-panel flex items-center justify-center flex-shrink-0 mt-1 border border-luxury-gold/20 overflow-hidden">
            <img src="images/AVATAR 2.png" alt="SL" class="w-full h-full object-cover">
        </div>
        <div class="px-5 py-4 rounded-2xl shadow-xl border bg-luxury-panel border-luxury-gold/40 rounded-tl-sm text-gray-200 bg-gradient-to-r from-luxury-panel to-luxury-gold/5 relative overflow-hidden">
             <!-- Shimmer Effect Background -->
            <div class="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-luxury-gold/10 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
            
            <div class="flex items-center gap-4 relative z-10">
                <div class="relative flex items-center justify-center w-6 h-6">
                    <i data-lucide="loader-2" class="w-6 h-6 text-luxury-gold animate-spin"></i>
                </div>
                <div class="flex flex-col">
                    <span class="text-sm font-semibold text-luxury-gold tracking-wide">Construindo o seu Protocolo...</span>
                    <span class="text-[11px] text-gray-400 mt-0.5">A equipe de inteligência artificial está processando os dados</span>
                </div>
            </div>
        </div>
    `;

    chatContainer.appendChild(div);
    lucide.createIcons();
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function removeGeneratingIndicator() {
    const bubble = document.getElementById('generating-indicator-bubble');
    if (bubble) bubble.remove();
}

// --- UI Helpers ---

function clearChatUI() {
    const messages = chatContainer.querySelectorAll('.message-content, .flex.gap-4');
    // Remove all except the typing indicator if present (though we usually remove it first)
    // Actually we want to remove everything inside chatContainer
    chatContainer.innerHTML = '';
}

function addWelcomeMessage() {
    const div = document.createElement('div');
    div.className = 'flex gap-4 animate-fade-in';
    div.innerHTML = `
        <div class="flex gap-4 animate-fade-in flex-col items-center mb-10 text-center w-full">
            <img src="images/BC2-ISL-LOGO.png" alt="Instituto Saúde de Luxo" class="h-24 object-contain mb-4">
            <div class="max-w-md bg-luxury-panel/50 backdrop-blur-sm p-6 rounded-2xl border border-white/5 shadow-2xl">
                <p class="text-lg text-white font-medium mb-3">Bem-vindo ao Sistema Inteligente</p>
                <p class="text-gray-400 text-sm leading-relaxed">
                    Olá, Dr(a). Sou sua consultora de elite. Desenvolverei para você um protocolo de vendas exclusivo e estratégico. Por onde gostaria de começar?
                </p>
            </div>
        </div>
    `;
    chatContainer.appendChild(div);
    lucide.createIcons();
}

function showTypingIndicator() {
    const div = document.createElement('div');
    div.id = 'typing-indicator-bubble';
    div.className = 'flex gap-4 animate-fade-in group';

    div.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-luxury-panel flex items-center justify-center flex-shrink-0 mt-1 border border-luxury-gold/20 overflow-hidden">
            <img src="images/AVATAR 2.png" alt="SL" class="w-full h-full object-cover">
        </div>
        <div class="px-5 py-3 rounded-2xl shadow-md border bg-luxury-panel border-white/5 rounded-tl-sm text-gray-200">
            <div class="flex items-center gap-3">
                <div class="flex gap-1.5 items-center">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
                <span class="typing-label">Digitando...</span>
            </div>
        </div>
    `;

    chatContainer.appendChild(div);
    lucide.createIcons();
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function removeTypingIndicator() {
    const bubble = document.getElementById('typing-indicator-bubble');
    if (bubble) {
        bubble.remove();
    }
}

function addMessage(text, sender, isError = false) {
    const div = document.createElement('div');
    div.className = 'flex gap-4 animate-fade-in group';

    const isAi = sender === 'ai';

    // Avatar
    const avatar = document.createElement('div');
    avatar.className = `w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 border overflow-hidden ${isAi ? 'bg-luxury-panel border-luxury-gold/20' : 'bg-gray-700 border-gray-600'}`;
    avatar.innerHTML = isAi
        ? '<img src="images/AVATAR 2.png" alt="SL" class="w-full h-full object-cover">'
        : '<i data-lucide="user" class="w-4 h-4 text-gray-300"></i>';

    // Content Bubble
    const content = document.createElement('div');
    content.className = `p-4 rounded-2xl shadow-md border ${isAi
        ? 'bg-luxury-panel border-white/5 rounded-tl-sm text-gray-200'
        : 'bg-luxury-accent border-white/5 rounded-tr-sm text-white ml-auto'
        } max-w-[85%] message-content prose`;

    if (isAi) {
        // Check for download tag
        const downloadRegex = /\[\[DOWNLOAD: (.*?)\]\]/;
        const match = (text || "").match(downloadRegex);
        let downloadUrl = null;
        let cleanText = text || "";

        if (match) {
            downloadUrl = match[1];
            cleanText = text.replace(match[0], '').trim();
        }

        // Parse Markdown
        content.innerHTML = marked.parse(cleanText);
        if (isError) content.classList.add('text-red-400');

        // Append Download Buttons if URL exists
        if (downloadUrl) {
            const btnContainer = document.createElement('div');
            btnContainer.className = 'mt-4 flex flex-wrap gap-2 justify-start';

            // Split downloads if multiple (Format: MD:url|DOCX:url|PDF:url)
            const downloads = downloadUrl.split('|');

            downloads.forEach(dl => {
                let label = 'Baixar';
                let url = dl;

                if (dl.includes(':')) {
                    const parts = dl.split(':');
                    label = parts[0];
                    url = parts.slice(1).join(':'); // Handle cases where URL might have colons
                }

                const btn = document.createElement('a');
                btn.href = url;
                btn.target = '_blank';
                btn.className = 'btn-download flex items-center gap-2 group/dl text-xs py-2 px-3';
                btn.innerHTML = `
                    <i data-lucide="download" class="w-3.5 h-3.5 transition-transform group-hover/dl:translate-y-1"></i>
                    <span>${label}</span>
                `;

                btnContainer.appendChild(btn);
            });
            content.appendChild(btnContainer);
        }

    } else {
        content.textContent = text;
        div.classList.add('flex-row-reverse'); // User messages on right
    }

    div.appendChild(avatar);
    div.appendChild(content);

    chatContainer.appendChild(div);

    // Re-initialize icons for new elements
    lucide.createIcons();

    // Scroll to bottom
    const mainContainer = document.getElementById('chat-container');
    mainContainer.scrollTop = mainContainer.scrollHeight;
}

// --- Custom Modal & Toast ---

function showConfirmModal(title, message) {
    return new Promise((resolve) => {
        confirmTitle.textContent = title;
        confirmMessage.textContent = message;

        // Show modal
        confirmModal.classList.remove('hidden');
        confirmModal.classList.add('modal-visible');
        lucide.createIcons();

        // Force reflow for animation
        requestAnimationFrame(() => {
            confirmCard.style.opacity = '1';
            confirmCard.style.transform = 'scale(1)';
        });

        function cleanup() {
            confirmCancelBtn.removeEventListener('click', onCancel);
            confirmOkBtn.removeEventListener('click', onConfirm);
            confirmOverlay.removeEventListener('click', onCancel);
            document.removeEventListener('keydown', onKeydown);
        }

        function closeModal() {
            confirmCard.style.opacity = '0';
            confirmCard.style.transform = 'scale(0.95)';
            setTimeout(() => {
                confirmModal.classList.add('hidden');
                confirmModal.classList.remove('modal-visible');
            }, 200);
        }

        function onCancel() {
            cleanup();
            closeModal();
            resolve(false);
        }

        function onConfirm() {
            cleanup();
            closeModal();
            resolve(true);
        }

        function onKeydown(e) {
            if (e.key === 'Escape') onCancel();
            if (e.key === 'Enter') onConfirm();
        }

        confirmCancelBtn.addEventListener('click', onCancel);
        confirmOkBtn.addEventListener('click', onConfirm);
        confirmOverlay.addEventListener('click', onCancel);
        document.addEventListener('keydown', onKeydown);
    });
}

const TOAST_ICONS = {
    error: 'x-circle',
    warning: 'alert-triangle',
    success: 'check-circle-2',
    info: 'info'
};

function showToast(message, type = 'info', duration = 4000) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    toast.innerHTML = `
        <i data-lucide="${TOAST_ICONS[type] || 'info'}" class="toast-icon"></i>
        <span>${message}</span>
    `;

    toastContainer.appendChild(toast);
    lucide.createIcons();

    // Auto-dismiss
    setTimeout(() => {
        toast.classList.add('toast-exit');
        toast.addEventListener('animationend', () => toast.remove());
    }, duration);
}

// --- Settings Panel ---

function setupSettings() {
    openSettingsBtn.addEventListener('click', openSettings);
    closeSettingsBtn.addEventListener('click', closeSettings);
    settingsOverlay.addEventListener('click', closeSettings);

    // Theme change
    themeSelect.addEventListener('change', (e) => {
        applyTheme(e.target.value);
        localStorage.setItem('sdl-theme', e.target.value);
        showToast('Tema atualizado!', 'success');
    });

    // Load AI model name from API
    fetchModelInfo();
}

async function fetchModelInfo() {
    try {
        const res = await fetch('/api/health');
        const data = await res.json();
        aiModelName.textContent = data.ai_model || 'Não disponível';
    } catch {
        aiModelName.textContent = 'Erro ao carregar';
    }
}

function openSettings() {
    settingsModal.classList.remove('hidden');
    settingsModal.classList.add('modal-visible');
    lucide.createIcons();
    requestAnimationFrame(() => {
        settingsCard.style.opacity = '1';
        settingsCard.style.transform = 'scale(1)';
    });
}

function closeSettings() {
    settingsCard.style.opacity = '0';
    settingsCard.style.transform = 'scale(0.95)';
    setTimeout(() => {
        settingsModal.classList.add('hidden');
        settingsModal.classList.remove('modal-visible');
    }, 200);
}

function loadTheme() {
    const saved = localStorage.getItem('sdl-theme') || 'dark';
    themeSelect.value = saved;
    applyTheme(saved);
}

function applyTheme(theme) {
    if (theme === 'light') {
        document.body.classList.add('theme-light');
    } else {
        document.body.classList.remove('theme-light');
    }
}

// Make functions valid for global scope usage via onclick
window.loadChat = loadChat;
window.deleteSession = deleteSession;
