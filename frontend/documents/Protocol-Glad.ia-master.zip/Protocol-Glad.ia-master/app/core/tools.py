import os
from typing import Dict, List, Optional, Union
import re

# Tentativa de importação de bibliotecas para leitura de documentos
try:
    from docx import Document
except ImportError:
    Document = None

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

# --- ESTADO DA SESSÃO (A "Memória" do Protocolo) ---
session_states: Dict[str, Dict] = {} 

def get_session_state(session_id: str) -> Dict:
    """
    Retorna ou inicializa o estado da sessão.
    Estrutura expandida para incluir o Briefing Visual.
    """
    if session_id not in session_states:
        session_states[session_id] = {
            # 1. Identidade e Autoridade (Agente Elena)
            "nome_medico": None,
            "especialidade": None,
            "missao_autoridade": None,
            "tempo_experiencia": None,

            # 2. Estrutura da Jornada (Agente Arquiteto)
            "fases": {
                "fase_1": None, 
                "fase_2": None, 
                "fase_3": None  
            },
            "tempo_total": None, 

            # 3. Gatilhos de Venda (Agente Impacto)
            "prognostico_nao_tratamento": None,
            "dor_paciente": None,

            # 4. Ancoragem Financeira (Agente Estrategista)
            "valor_avulso": None,
            "valor_protocolo": None,
            "bonus_inclusos": [],
            "gatilho_urgencia": None,
            
            # 5. Identidade Visual (Novo Agente Designer)
            "briefing_visual": {
                "estilo": "Minimalista", # Padrão
                "cores": "Preto e Branco",
                "formato": "Carrossel"
            },

            # Controle de Status
            "status": "EM_CONSTRUCAO"
        }
    return session_states[session_id]

def limpar_estado_sessao(session_id: str) -> None:
    if session_id in session_states:
        del session_states[session_id]

# --- HELPER: Formatação de Luxo ---
def formatar_moeda(valor: str) -> str:
    """Transforma entradas como '5000', '5k', '5000.00' em 'R$ 5.000,00'"""
    if not valor: return "Sob Consulta"
    
    # Remove caracteres não numéricos exceto ponto e vírgula
    limpo = re.sub(r'[^\d,.]', '', str(valor).lower().replace('k', '000'))
    
    try:
        # Tenta converter para float (assumindo ponto como decimal se houver)
        if ',' in limpo and '.' in limpo: # Formato brasileiro misturado
             limpo = limpo.replace('.', '').replace(',', '.')
        elif ',' in limpo: # Formato brasileiro puro
             limpo = limpo.replace(',', '.')
             
        numero = float(limpo)
        return f"R$ {numero:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except:
        return valor # Retorna original se falhar

# --- 1. FERRAMENTAS DE ARQUIVO ---

def criar_ferramenta_ler_documento(session_id: str):
    def ler_conteudo_arquivo(caminho_arquivo: str) -> str:
        """Lê arquivos PDF ou DOCX para extrair contexto."""
        if not os.path.exists(caminho_arquivo):
            return "ERRO: Arquivo não encontrado."

        texto_extraido = ""
        _, extensao = os.path.splitext(caminho_arquivo)
        extensao = extensao.lower()

        try:
            if extensao == ".docx":
                if Document is None: return "ERRO: Instale python-docx"
                doc = Document(caminho_arquivo)
                texto_extraido = "\n".join([para.text for para in doc.paragraphs])
            
            elif extensao == ".pdf":
                if PdfReader is None: return "ERRO: Instale pypdf"
                reader = PdfReader(caminho_arquivo)
                for page in reader.pages:
                    if page.extract_text():
                        texto_extraido += page.extract_text() + "\n"
            else:
                return "ERRO: Formato não suportado (apenas .pdf ou .docx)."

            return f"CONTEÚDO DO ARQUIVO:\n{texto_extraido[:50000]}"

        except Exception as e:
            return f"ERRO CRÍTICO: {str(e)}"

    return ler_conteudo_arquivo

# --- 2. FERRAMENTAS DOS AGENTES ---

def criar_ferramenta_salvar_autoridade(session_id: str):
    def salvar_autoridade(nome: str, especialidade: str, missao: str, tempo_experiencia: str) -> str:
        """Salva a identidade do médico (Elena)."""
        state = get_session_state(session_id)
        state["nome_medico"] = nome
        state["especialidade"] = especialidade
        state["missao_autoridade"] = missao
        state["tempo_experiencia"] = tempo_experiencia
        return f"Identidade registrada: Dr(a) {nome} ({especialidade})."
    return salvar_autoridade

def criar_ferramenta_definir_fases(session_id: str):
    def salvar_fases_jornada(detalhes_fase_1: str, detalhes_fase_2: str, detalhes_fase_3: str, tempo_total: str) -> str:
        """Salva as 3 fases da jornada contendo os nomes, entregáveis exatos e tempo de duração de cada uma, além do tempo total de tratamento (Ex: 6 meses)."""
        state = get_session_state(session_id)
        state["fases"]["fase_1"] = detalhes_fase_1
        state["fases"]["fase_2"] = detalhes_fase_2
        state["fases"]["fase_3"] = detalhes_fase_3
        state["tempo_total"] = tempo_total
        return f"Fases da Jornada e tempo total ({tempo_total}) estruturados."
    return salvar_fases_jornada

def criar_ferramenta_salvar_prognostico(session_id: str):
    def salvar_riscos_nao_tratamento(principal_dor_atual: str, consequencias_futuras: str) -> str:
        """Salva a 'Ponte de Ouro' e riscos (Impacto)."""
        state = get_session_state(session_id)
        state["dor_paciente"] = principal_dor_atual
        state["prognostico_nao_tratamento"] = consequencias_futuras
        return "Urgência ética e prognóstico registrados."
    return salvar_riscos_nao_tratamento

def criar_ferramenta_ancoragem_valor(session_id: str):
    def salvar_investimento(valor_avulso_total: str, valor_protocolo: str, lista_bonus: str, gatilho_urgencia: str = "") -> str:
        """Salva a oferta financeira com formatação automática e gatilho de urgência (Estrategista)."""
        state = get_session_state(session_id)
        
        # Aplica formatação de luxo (R$)
        state["valor_avulso"] = formatar_moeda(valor_avulso_total)
        state["valor_protocolo"] = formatar_moeda(valor_protocolo)
        
        state["bonus_inclusos"] = [b.strip() for b in lista_bonus.split(",")] if lista_bonus else []
        state["gatilho_urgencia"] = gatilho_urgencia
        state["status"] = "PRONTO_PARA_GERACAO"
        
        return f"Oferta salva. De: {state['valor_avulso']} Por: {state['valor_protocolo']}."
    return salvar_investimento

# --- NOVA FERRAMENTA: DESIGN VISUAL ---
def criar_ferramenta_salvar_briefing_visual(session_id: str):
    def salvar_briefing(estilo_visual: str, cores_predominantes: str, formato_preferido: str) -> str:
        """
        Salva as preferências visuais para o time de design.
        - estilo_visual: ex: "Minimalista", "Dark Luxury", "Científico".
        - cores_predominantes: ex: "Dourado e Preto", "Azul Marinho e Branco".
        - formato_preferido: ex: "Carrossel Instagram", "PDF A4", "Story".
        """
        state = get_session_state(session_id)
        state["briefing_visual"] = {
            "estilo": estilo_visual,
            "cores": cores_predominantes,
            "formato": formato_preferido
        }
        return f"Briefing Visual salvo: Estilo {estilo_visual} em tons de {cores_predominantes}."
    return salvar_briefing

# --- 3. FERRAMENTA DE EDIÇÃO ---

def criar_ferramenta_editar_dado(session_id: str):
    def editar_campo_especifico(campo: str, novo_valor: str) -> str:
        """Edita campos. Opções: nome, missao, fase_1, fase_2, fase_3, riscos, valor, estilo_visual."""
        state = get_session_state(session_id)
        
        mapa = {
            "nome": "nome_medico",
            "missao": "missao_autoridade",
            "riscos": "prognostico_nao_tratamento",
            "dor": "dor_paciente",
            "fase_1": ["fases", "fase_1"],
            "fase_2": ["fases", "fase_2"],
            "fase_3": ["fases", "fase_3"],
            "valor": "valor_protocolo",
            "estilo_visual": ["briefing_visual", "estilo"] # Adicionado mapeamento visual
        }

        try:
            if campo in mapa:
                chave = mapa[campo]
                if isinstance(chave, list):
                    state[chave[0]][chave[1]] = novo_valor
                else:
                    state[chave] = novo_valor
            elif campo in state:
                state[campo] = novo_valor
            else:
                return f"Campo '{campo}' não reconhecido."

            return f"Atualizado: '{campo}'."
        except Exception as e:
            return f"Erro na edição: {str(e)}"
    return editar_campo_especifico

# --- FERRAMENTA DE TESTE RÁPIDO ---
def criar_ferramenta_preencher_teste(session_id: str):
    def preencher_dados_exemplo_luxo() -> str:
        """
        Preenche instantaneamente todos os dados da sessão com informações de um protocolo de exemplo 
        de alto padrão (Odontologia Estética) para testar a geração do CrewAI.
        """
        state = get_session_state(session_id)
        state.update({
            "nome_medico": "Cristiano Ronaldo",
            "especialidade": "Odontologia de Alta Performance",
            "missao_autoridade": "Esculpir sorrisos que refletem a alma e o sucesso de líderes mundiais.",
            "tempo_experiencia": "15 anos entre Europa e Brasil",
            "fases": {
                "fase_1": "Bio-Alinhamento Térmico", 
                "fase_2": "Arquitetura Digital de Facetas", 
                "fase_3": "Blindagem e Atemporalidade"  
            },
            "tempo_total": "4 meses",
            "dor_paciente": "Medo de perder a naturalidade e vergonha de sorrir em reuniões de alto escalão.",
            "prognostico_nao_tratamento": "Perda da autoridade visual, retração óssea severa e isolamento social progressivo.",
            "valor_avulso": "R$ 85.000,00",
            "valor_protocolo": "R$ 52.000,00",
            "bonus_inclusos": ["Concierge 24/7", "Kit de Manutenção Home Care de Luxo", "Sessão de Fotos Profissionais"],
            "gatilho_urgencia": "Condição EXCLUSIVA e parcelamento especial válido apenas para fechamento nas próximas 24h.",
            "briefing_visual": {
                "estilo": "Dark Luxury",
                "cores": "Ouro e Obsidian",
                "formato": "PDF A4 Premium"
            },
            "nome_clinica": "Instituto Odontológico Premium",
            "status": "PRONTO_PARA_GERACAO"
        })
        return "MODO TESTE ATIVADO: Todos os dados foram preenchidos com um exemplo de Odontologia Estética. Você já pode gerar o protocolo."
    return preencher_dados_exemplo_luxo

# --- 4. GERAÇÃO DO PROTOCOLO (SAÍDA FINAL) ---

from app.core.crew_swarm import generate_sales_protocol

def criar_ferramenta_gerar_protocolo(session_id: str):
    def disparar_criacao_documento() -> str:
        """
        Dispara a CrewAI para gerar o documento final com base nos dados coletados.
        """
        state = get_session_state(session_id)
        
        if not state["nome_medico"]:
             return "ERRO: Faltam dados. Complete a entrevista com a Glad.IA."

        # Formata bônus como string legível
        bonus_str = ", ".join(state.get("bonus_inclusos", [])) if state.get("bonus_inclusos") else "Não definidos"
        
        # Inputs estruturados — cada campo separado para os placeholders das tasks
        inputs = {
            # Dados do Médico
            'nome_medico': state.get('nome_medico', ''),
            'especialidade': state.get('especialidade', ''),
            'missao_autoridade': state.get('missao_autoridade', ''),
            'tempo_experiencia': state.get('tempo_experiencia', ''),
            
            # Dados do Paciente / Problema  
            'dor_paciente': state.get('dor_paciente', ''),
            'prognostico_nao_tratamento': state.get('prognostico_nao_tratamento', ''),
            
            # Fases do Tratamento
            'fase_1': state['fases'].get('fase_1', ''),
            'fase_2': state['fases'].get('fase_2', ''),
            'fase_3': state['fases'].get('fase_3', ''),
            'tempo_total': state.get('tempo_total', 'Não especificado'),
            
            # Financeiro
            'valor_avulso': state.get('valor_avulso', ''),
            'valor_protocolo': state.get('valor_protocolo', ''),
            'bonus_inclusos': bonus_str,
            'gatilho_urgencia': state.get('gatilho_urgencia', ''),
            
            # Dados da Instituição
            'nome_clinica': state.get('nome_clinica', 'Instituto Saúde de Luxo'),
        }
        
        # Atualiza o status para o frontend exibir a animação de geração
        state["status"] = "GERANDO_PROTOCOLO"
        
        try:
            # Chama a CrewAI
            result = generate_sales_protocol(inputs)
        finally:
            # Restaura o status ao concluir a geração
            state["status"] = "CONCLUIDO"
        
        return result

    return disparar_criacao_documento
