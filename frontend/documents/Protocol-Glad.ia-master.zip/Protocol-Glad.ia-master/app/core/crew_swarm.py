import os
import re
import uuid
from typing import Dict, Any
from app.core.crew import ProtocoloCriacao

# Tentativa de importação para DOCX e PDF
try:
    from docx import Document
    from docx.shared import Pt, Inches, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn, nsdecls
    from docx.oxml import parse_xml
except ImportError:
    Document = None

try:
    import markdown
    from xhtml2pdf import pisa
except ImportError:
    markdown = None
    pisa = None


# ==========================================
# HELPERS PARA DOCX PREMIUM
# ==========================================

# Cores do tema premium (Alto Padrão)
GOLD = RGBColor(0xD4, 0xAF, 0x37) if Document else None
DARK = RGBColor(0x2A, 0x2A, 0x2A) if Document else None
WHITE = RGBColor(0xFF, 0xFF, 0xFF) if Document else None
LIGHT_GRAY = RGBColor(0xF5, 0xF5, 0xF5) if Document else None
MEDIUM_GRAY = RGBColor(0x55, 0x55, 0x55) if Document else None


def _set_cell_shading(cell, color_hex: str):
    """Aplica cor de fundo a uma célula do Word."""
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shading)


def _set_cell_border(cell, **kwargs):
    """Define bordas de célula. Ex: top=('single','4','D4AF37')"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}></w:tcBorders>')
    for edge, vals in kwargs.items():
        style, size, color = vals
        el = parse_xml(
            f'<w:{edge} {nsdecls("w")} w:val="{style}" w:sz="{size}" '
            f'w:space="0" w:color="{color}"/>'
        )
        tcBorders.append(el)
    tcPr.append(tcBorders)


def _process_text_runs(p, text, is_bold=False, font_size=11, font_name="Calibri", color=None):
    """Processa texto contendo bold (**texto**) e tachado/strikethrough (~~texto~~) para ancoragem."""
    # Primeiro divide por tachado
    parts_strike = re.split(r'(~~.*?~~)', text)
    
    for part_s in parts_strike:
        strike_flag = False
        if part_s.startswith('~~') and part_s.endswith('~~'):
            strike_flag = True
            part_s = part_s[2:-2]
        
        # Depois divide por negrito
        parts_bold = re.split(r'(\*\*.*?\*\*)', part_s)
        for part_b in parts_bold:
            bold_flag = is_bold
            if part_b.startswith('**') and part_b.endswith('**'):
                bold_flag = True
                part_b = part_b[2:-2]
            
            if part_b:
                run = p.add_run(part_b)
                run.bold = bold_flag
                run.font.strike = strike_flag
                run.font.size = Pt(font_size)
                run.font.name = font_name
                if color:
                    run.font.color.rgb = color

def _add_styled_paragraph(doc, text, bold=False, font_size=11, color=None, 
                           alignment=None, space_after=6, font_name="Calibri"):
    """Adiciona parágrafo com estilo customizado."""
    p = doc.add_paragraph()
    if alignment:
        p.alignment = alignment
    p.paragraph_format.space_after = Pt(space_after)
    
    _process_text_runs(p, text, is_bold=bold, font_size=font_size, font_name=font_name, color=color)
    return p


def _parse_markdown_table(lines):
    """Extrai dados de tabela a partir de linhas markdown."""
    table_data = []
    for line in lines:
        line = line.strip()
        if line.startswith('|') and not re.match(r'^\|[\s\-:|]+\|$', line):
            cells = [c.strip() for c in line.split('|')[1:-1]]
            if cells:
                table_data.append(cells)
    return table_data


def _add_premium_table(doc, table_data):
    """Adiciona tabela formatada ao DOCX com estilo premium."""
    if not table_data:
        return
    
    num_cols = max(len(row) for row in table_data)
    table = doc.add_table(rows=0, cols=num_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    for row_idx, row_data in enumerate(table_data):
        row = table.add_row()
        for col_idx in range(num_cols):
            cell = row.cells[col_idx]
            cell_text = row_data[col_idx] if col_idx < len(row_data) else ""
            
            # Limpa parágrafos existentes
            cell.paragraphs[0].text = ""
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # Processa formatação inline (bold e tachado)
            _process_text_runs(p, cell_text, font_size=9, font_name="Calibri")
            
            # Estilo do header (Sessão 4)
            if row_idx == 0:
                _set_cell_shading(cell, "2A2A2A")
                for run in p.runs:
                    run.font.color.rgb = WHITE
                    run.font.bold = True
                    run.font.size = Pt(10)
            else:
                # Linhas de fase (detectar pelo conteúdo)
                if cell_text.lower().startswith("fase"):
                    _set_cell_shading(cell, "F0E6C8")
                    for run in p.runs:
                        run.font.bold = True
                        run.font.color.rgb = DARK
                elif "total" in cell_text.lower() or "bônus" in cell_text.lower():
                    _set_cell_shading(cell, "E8E8E8")
                    for run in p.runs:
                        run.font.bold = True
                elif row_idx % 2 == 0:
                    _set_cell_shading(cell, "FAFAFA")
            
            # Bordas Douradas/Cinzas
            _set_cell_border(cell, 
                bottom=("single", "4", "D4AF37" if row_idx == 0 else "E0E0E0"),
                top=("single", "4", "E0E0E0"),
                left=("single", "2", "E0E0E0"),
                right=("single", "2", "E0E0E0"))


def _build_premium_docx(result_text: str, output_path: str, inputs: dict):
    """Constrói DOCX premium a partir do Markdown gerado pelo CrewAI."""
    doc = Document()
    
    # Configurar margens
    for section in doc.sections:
        section.top_margin = Cm(2)
        section.bottom_margin = Cm(2)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)
    
    lines = result_text.split('\n')
    in_table = False
    table_lines = []
    
    for line in lines:
        stripped = line.strip()
        
        # Detectar tabela markdown
        if stripped.startswith('|'):
            if not in_table:
                in_table = True
                table_lines = []
            table_lines.append(stripped)
            continue
        elif in_table:
            # Tabela terminou, renderizar
            table_data = _parse_markdown_table(table_lines)
            if table_data:
                _add_premium_table(doc, table_data)
                doc.add_paragraph()  # Espaço após tabela
            in_table = False
            table_lines = []
        
        # Pular linhas vazias
        if not stripped:
            continue
        
        # Separadores horizontais de Sessões (ex: ━━━━━━━━━━ ou ---)
        if stripped in ('---', '***', '___') or re.match(r'^[-━_]{3,}$', stripped):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            run.font.color.rgb = GOLD
            run.font.size = Pt(10)
            continue
        
        # Headings (Títulos)
        if stripped.startswith('# '):
            heading = doc.add_heading(stripped[2:], level=1)
            heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in heading.runs:
                run.font.color.rgb = GOLD
                run.font.name = "Calibri"
                run.font.bold = True
            continue
        
        if stripped.startswith('## '):
            heading = doc.add_heading(stripped[3:], level=2)
            for run in heading.runs:
                run.font.color.rgb = DARK
                run.font.name = "Calibri"
                run.font.bold = True
            continue
        
        if stripped.startswith('### '):
            heading = doc.add_heading(stripped[4:], level=3)
            for run in heading.runs:
                run.font.color.rgb = MEDIUM_GRAY
                run.font.name = "Calibri"
            continue
        
        # Listas de Entregáveis e Gatilhos
        if stripped.startswith('- ') or stripped.startswith('• '):
            item_text = stripped[2:]
            _add_styled_paragraph(doc, f"• {item_text}", font_size=11, color=DARK)
            continue
        
        if re.match(r'^\d+[\.\)]\s', stripped):
            _add_styled_paragraph(doc, stripped, font_size=11, color=DARK)
            continue
        
        # Placeholders de imagem (Logo e Foto da Autoridade)
        if stripped.startswith('[') and ']' in stripped and any(
            kw in stripped.upper() for kw in ['FOTO', 'LOGO', 'IMAGEM']
        ):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(f"📷 {stripped}")
            run.font.color.rgb = MEDIUM_GRAY
            run.font.size = Pt(10)
            run.italic = True
            continue
        
        # Parágrafo normal
        _add_styled_paragraph(doc, stripped, font_size=11, color=DARK)
    
    # Renderizar tabela pendente no final
    if in_table and table_lines:
        table_data = _parse_markdown_table(table_lines)
        if table_data:
            _add_premium_table(doc, table_data)
    
    # === RODAPÉ DE AUTORIDADE ===
    p_line = doc.add_paragraph()
    p_line.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p_line.add_run("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    run.font.color.rgb = GOLD
    run.font.size = Pt(10)
    
    p_footer = doc.add_paragraph()
    p_footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    # Pega o nome da clínica do input, ou usa um texto neutro
    nome_clinica_rodape = inputs.get('nome_clinica', 'Atendimento High Ticket')
    run = p_footer.add_run(nome_clinica_rodape)
    run.font.color.rgb = GOLD
    run.font.size = Pt(9)
    run.italic = True
    
    doc.save(output_path)


# ==========================================
# CSS PREMIUM PARA PDF (ReportLab/XHTML2PDF)
# ==========================================

PDF_CSS = """
@page {
    margin: 2cm;
}
body { 
    font-family: Helvetica, sans-serif; 
    color: #2A2A2A; 
    font-size: 11pt; 
    line-height: 1.5; 
}
h1 { 
    color: #D4AF37; 
    text-align: center; 
    font-size: 18pt; 
    margin-bottom: 20px;
}
h2 { 
    color: #2A2A2A; 
    border-bottom: 2px solid #D4AF37; 
    padding-bottom: 5px; 
    font-size: 14pt;
    margin-top: 25px;
}
h3 { 
    color: #555555; 
    font-size: 12pt;
}
table { 
    border-collapse: collapse; 
    width: 100%; 
    margin-top: 20px;
    margin-bottom: 20px; 
    font-size: 10pt; 
}
th, td { 
    border: 1px solid #E0E0E0; 
    padding: 8px; 
    text-align: left; 
}
th { 
    background-color: #2A2A2A; 
    color: #FFFFFF; 
    font-weight: bold; 
    text-align: center; 
    border-bottom: 3px solid #D4AF37;
}
td:first-child {
    font-weight: bold;
    background-color: #FAFAFA;
}
del { 
    color: #999999; 
} /* Estilo para o tachado da ancoragem */
hr { 
    color: #D4AF37; 
    background-color: #D4AF37; 
    height: 1px; 
    border: none; 
    margin: 25px 0;
}
.footer-gold { 
    text-align: center; 
    color: #D4AF37; 
    font-size: 9pt; 
    margin-top: 30px; 
    font-style: italic; 
    border-top: 1px solid #D4AF37;
    padding-top: 10px;
}
"""

def generate_sales_protocol(inputs: Dict[str, Any]) -> str:
    """
    Gera o protocolo de vendas High-Ticket em formatos MD, DOCX e PDF.
    """
    # Executa o CrewAI
    protocol_crew = ProtocoloCriacao()
    crew_output = protocol_crew.crew().kickoff(inputs=inputs)
    result_text = str(crew_output.raw)
    
    # --- Geração de Arquivos ---
    base_id = uuid.uuid4().hex[:8]
    md_filename = f"protocolo_{base_id}.md"
    docx_filename = f"protocolo_{base_id}.docx"
    pdf_filename = f"protocolo_{base_id}.pdf"
    
    output_dir = os.path.join("frontend", "documents")
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Salvar MD
    md_path = os.path.join(output_dir, md_filename)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(result_text)
        
    # 2. Salvar DOCX (Premium High-Ticket)
    if Document:
        try:
            docx_path = os.path.join(output_dir, docx_filename)
            _build_premium_docx(result_text, docx_path, inputs)
        except Exception as e:
            print(f"Erro ao gerar DOCX: {e}")

    # 3. Salvar PDF
    if markdown and pisa:
        try:
            # Extensão 'sane_lists' e 'tables' são essenciais.
            html_body = markdown.markdown(
                result_text, 
                extensions=['tables', 'fenced_code', 'nl2br', 'sane_lists']
            )
            
            # Substitui o tachado (~~) do markdown para a tag <del> do HTML para a ancoragem funcionar no PDF
            html_body = re.sub(r'~~(.*?)~~', r'<del>\1</del>', html_body)
            
            # Pega o nome da clínica do input, ou usa um texto neutro
            nome_clinica_pdf = inputs.get('nome_clinica', 'Atendimento High Ticket')
            
            styled_html = f"""
            <html>
                <head>
                    <meta charset="utf-8">
                    <style>{PDF_CSS}</style>
                </head>
                <body>
                    {html_body}
                    <div class='footer-gold'>{nome_clinica_pdf}</div>
                </body>
            </html>
            """
            
            pdf_path = os.path.join(output_dir, pdf_filename)
            with open(pdf_path, "wb") as f:
                pisa_status = pisa.CreatePDF(styled_html.encode('utf-8'), dest=f, encoding='utf-8')
                
            if pisa_status.err:
                print(f"Erro ao gerar PDF (Pisa): {pisa_status.err}")
        except Exception as e:
            print(f"Exceção ao gerar PDF: {e}")

    # Tag de download para o frontend
    final_response = (
        f"💎 Protocolo Definitivo gerado com sucesso!\n\n"
        f"A estratégia foi montada utilizando as técnicas de Ancoragem de Preço e Gatilho de Urgência (24h). "
        f"Os documentos nos formatos Word, PDF e Markdown estão prontos abaixo.\n\n"
        f"[[DOWNLOAD: MD:/documents/{md_filename}|DOCX:/documents/{docx_filename}|PDF:/documents/{pdf_filename}]]"
    )
    
    return final_response