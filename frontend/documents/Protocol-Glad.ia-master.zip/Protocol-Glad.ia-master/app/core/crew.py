import os 
from crewai import Agent, Crew, Process, Task, LLM
from typing import List
import yaml

from app.core.config import settings

# Helper to load yaml config
def load_config(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

class ProtocoloCriacao():
    """ProtocoloCriacao crew"""
    
    def __init__(self):
        # Use absolute paths relative to this file's location
        base_path = os.path.dirname(os.path.abspath(__file__))
        config_dir = os.path.join(base_path, "config", "protocol_crew")
        
        self.agents_config = load_config(os.path.join(config_dir, "agents.yaml"))
        self.tasks_config = load_config(os.path.join(config_dir, "tasks.yaml"))
        
        self.my_llm = LLM(
            model=f"gemini/{settings.AI_MODEL_NAME}", 
            api_key=settings.GOOGLE_API_KEY
        )

    # --- AGENTES ---

    def input_analyst(self) -> Agent:
        cfg = self.agents_config['input_analyst']
        return Agent(
            role=cfg['role'],
            goal=cfg['goal'],
            backstory=cfg['backstory'],
            verbose=True,
            llm=self.my_llm
        )

    def health_copywriter(self) -> Agent:
        cfg = self.agents_config['health_copywriter']
        return Agent(
            role=cfg['role'],
            goal=cfg['goal'],
            backstory=cfg['backstory'],
            verbose=True,
            llm=self.my_llm
        )

    def protocol_architect(self) -> Agent:
        cfg = self.agents_config['protocol_architect']
        return Agent(
            role=cfg['role'],
            goal=cfg['goal'],
            backstory=cfg['backstory'],
            verbose=True,
            llm=self.my_llm
        )

    def financial_analyst(self) -> Agent:
        cfg = self.agents_config['financial_analyst']
        return Agent(
            role=cfg['role'],
            goal=cfg['goal'],
            backstory=cfg['backstory'],
            verbose=True,
            llm=self.my_llm
        )

    def chief_editor(self) -> Agent:
        cfg = self.agents_config['chief_editor']
        return Agent(
            role=cfg['role'],
            goal=cfg['goal'],
            backstory=cfg['backstory'],
            verbose=True,
            llm=self.my_llm,
            allow_delegation=False
        )

    # --- TAREFAS ---

    def _make_task(self, key: str, agent: Agent, context: list = None) -> Task:
        cfg = self.tasks_config[key]
        kwargs = dict(
            description=cfg['description'],
            expected_output=cfg['expected_output'],
            agent=agent,
        )
        if context:
            kwargs['context'] = context
        return Task(**kwargs)

    # --- CREW ---

    def crew(self) -> Crew:
        """Creates the ProtocoloCriacao crew"""
        analyst     = self.input_analyst()
        copywriter  = self.health_copywriter()
        architect   = self.protocol_architect()
        financial   = self.financial_analyst()
        editor      = self.chief_editor()

        t_validate  = self._make_task('data_validation_task',   analyst)
        t_narrative = self._make_task('narrative_strategy_task', copywriter)
        t_clinical  = self._make_task('clinical_structure_task', architect)
        t_pricing   = self._make_task('commercial_pricing_task', financial)
        t_final     = self._make_task('final_assembly_task',     editor,
                                      context=[t_narrative, t_clinical, t_pricing])

        return Crew(
            agents=[analyst, copywriter, architect, financial, editor],
            tasks=[t_validate, t_narrative, t_clinical, t_pricing, t_final],
            process=Process.sequential,
            verbose=True,
        )
